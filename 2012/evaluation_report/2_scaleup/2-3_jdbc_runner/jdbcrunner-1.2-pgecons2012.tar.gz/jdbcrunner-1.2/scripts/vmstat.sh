#!/bin/bash

INTERVAL=10
nohup ssh -tt postgres@172.17.177.21 "vmstat ${INTERVAL}" >> vmstat_server.log &
echo $! > vmstatsProc.txt
#res=$!
