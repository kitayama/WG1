cp ./tpcc.js.256ses ./tpcc.js
su postgres -c ./tpcc.sh
#cp ./tpcc.js.16ses ./tpcc.js
#su postgres -c ./tpcc.sh
#cp ./tpcc.js.32ses ./tpcc.js
#su postgres -c ./tpcc.sh
#cp ./tpcc.js.64ses ./tpcc.js
#su postgres -c ./tpcc.sh
cp ./tpcc.js.128ses ./tpcc.js
su postgres -c ./tpcc.sh
#cp ./tpcc.js.256ses ./tpcc.js
#su postgres -c ./tpcc.sh
#cp ./tpcc.js.512ses ./tpcc.js
#su postgres -c ./tpcc.sh
#cp ./tpcc.js.1024ses ./tpcc.js
#su postgres -c ./tpcc.sh
