#!/bin/bash

cp -f /home/postgres/nes/postgresql.conf.load  /test2/data/postgresql.conf
pg_ctl stop
pg_ctl -w start
nohup java JR tpcc_copy.js -param0 $1 >> copy.txt 2>&1 &

